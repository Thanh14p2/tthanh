import requests
def gettik(url):
  cookies = {
    'current_language': 'en',
    '_ga': 'GA1.1.1655375114.1704617346',
    '_gcl_au': '1.1.1282022684.1704617346',
    '_ga_5370HT04Z3': 'GS1.1.1704617346.1.1.1704617367.0.0.0',
}
  headers = {
    'authority': 'tikwm.com',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': 'current_language=en; _ga=GA1.1.1655375114.1704617346; _gcl_au=1.1.1282022684.1704617346; _ga_5370HT04Z3=GS1.1.1704617346.1.1.1704617367.0.0.0',
    'origin': 'https://tikwm.com',
    'referer': 'https://tikwm.com/',
    'sec-ch-ua': '"Chromium";v="105", "Not)A;Brand";v="8"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
  data = {
    'url': url,
    'count': '12',
    'cursor': '0',
    'web': '1',
    'hd': '1',
}
  response = requests.post('https://tikwm.com/api/', cookies=cookies, headers=headers, data=data).json()
  title=response['data']['title']
  duration=response['data']['duration']
  tym=response['data']['digg_count']
  comment_count=response['data']['comment_count']
  share_count=response['data']['share_count']
  download_count=response['data']['download_count']
  nickname=response['data']['author']['nickname']
  unique_id=response['data']['author']['unique_id']
  hdplay=response['data']['hdplay']
  down=requests.get(f'https://tikwm.com{hdplay}',headers=headers,cookies=cookies).content
  open('tiktok.mp4','wb').write(down)
  return title,duration,tym,comment_count,share_count,download_count,nickname,unique_id
