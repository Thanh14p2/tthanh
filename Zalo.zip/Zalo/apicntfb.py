import requests
import json
def checkid(uid):
  check=requests.get(f'https://graph.facebook.com/{uid}?fields=id,is_verified,cover,created_time,work,hometown,username,link,name,locale,location,about,website,birthday,gender,relationship_status,significant_other,quotes,first_name,subscribers.limit(0)&access_token=EAAD6V7os0gcBO0DxLhGEODH9aBqkKdw8dNOIQE9bIB5LFdshSkPQsaFodR9kPUuWdIbegkFzEAosD96n5fxc6ZB9AKEGV8IIhw0awT6zzT9H8P8YgjaJATQAZCpVLBeEBQQpuvjUKqXxfrwZBOc5aHYnriF1X5gpi1kTxHkk76g0QwZCZBudJhb7PglQlrWAnfQZDZD').json()
  #avarta=requests.get(f'https://graph.facebook.com/{uid}/picture?redirect=0&type=normal&height=350&width=350&access_token=EAAD6V7os0gcBO4OpqsbZBTf7GN4w1QxbVQZAgfGVKiZC5DYdcu4iSNfw7cY5oOZALAFEcZAyP1U9VhvZAALZBaHdcEmhUYNGUHcX3PJFA042z8jseJYa1xWbtrwB7vFWD2y8SFXsjugmfm4LUj0YhUmruvZBRNgg4Cw6e5gWPLB7Ilc3lOJ2eFsB56oSSQZDZD').json()
  idfb=check['id']
  #avarta=avarta['data']['url']
  created_time=check['created_time']
  hometown=check.get('hometown',{}).get('name')
  username=check.get('username')
  name=check['name']
  locale=check.get('locale')
  location=check.get('location',{}).get('name')
  website=check.get('website')
  birthday=check.get('birthday')
  gender=check.get('gender')
  relationship_status=check.get('relationship_status')
  first_name=check['first_name']
  subscribers=check['subscribers']['summary']["total_count"]
  link=check['link']
  data = {'idfb':idfb, 'link':link, 'created_time':created_time, 'hometown':hometown, 'username':username, 'name':name,
  'locale':locale, 'location':location, 'website':website, 'birthday':birthday, 'gender':gender, 'relationship_status':relationship_status, 'first_name':first_name, 'subscribers':subscribers}
  check=json.loads(json.dumps(data,indent=13))
  return check



