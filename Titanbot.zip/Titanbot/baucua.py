import random

class Game:
    def __init__(self):
        self.player1_id = 1
        self.player2_id = 2
        self.player1_money = 100000
        self.player2_money = 100000
        self.choices = ["cá", "tôm", "gà", "hươu", "bầu", "cua"]

    def play_round(self, player1_choice, player2_choice, bet_amount):
        result = [random.choice(self.choices) for _ in range(3)]

        print(f"Player 1 chose {player1_choice}, Player 2 chose {player2_choice}, result: {result}")

        if player1_choice in result:
            if result.count(player1_choice) == 1:
                multiplier = 1.5
            elif result.count(player1_choice) == 2:
                multiplier = 3
            else:
                multiplier = 5

            winnings = bet_amount * multiplier
            print(f"Player 1 won {winnings} money.")
            self.player1_money += winnings
        else:
            print("Player 1 lost.")
            self.player1_money -= bet_amount

        if player2_choice in result:
            if result.count(player2_choice) == 1:
                multiplier = 1.5
            elif result.count(player2_choice) == 2:
                multiplier = 3
            else:
                multiplier = 5

            winnings = bet_amount * multiplier
            print(f"Player 2 won {winnings} money.")
            self.player2_money += winnings
        else:
            print("Player 2 lost.")
            self.player2_money -= bet_amount

    def play_game(self):
        while self.player1_money > 0 and self.player2_money > 0:
            player1_choice = input("Player 1, choose (cá/tôm/gà/hươu/bầu/cua): ").lower()
            player2_choice = input("Player 2, choose (cá/tôm/gà/hươu/bầu/cua): ").lower()
            bet_amount = int(input("Enter bet amount: "))

            self.play_round(player1_choice, player2_choice, bet_amount)

            print(f"Player 1 money: {self.player1_money}, Player 2 money: {self.player2_money}")

        print("Game Over")

# Create and play the game
game = Game()
game.play_game()
