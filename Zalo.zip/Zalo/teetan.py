from zlapi import ZaloAPI
from zlapi.models import Message
import requests
from apicntfb import checkid
from share import run
from time import sleep
import threading

class TeeTan(ZaloAPI):
    def __init__(self, phone, passzl, imei, session_cookies):
        super().__init__(phone, passzl, imei=imei, session_cookies=session_cookies)
        self.share = False

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        try:
            if author_id != self.uid and thread_id == '4129156594174902737' or author_id == '6949019840942160627':
                self.markAsDelivered(mid, message_object.cliMsgId, author_id, thread_id, thread_type, message_object.msgType)
                self.markAsRead(mid, message_object.cliMsgId, author_id, thread_id, thread_type, message_object.msgType)
                
                print(f"Received message: {message} from {author_id} in thread {thread_id}, type {thread_type}, {message_object}")
                
                # If message is not a string, set message to "[not a message]"
                if not isinstance(message, str):
                    message = "[not a message]"
                
                # Echo back if the message starts with 'Bot'
                if message.startswith('Bot'):
                    reply = 'Hello My Fen'
                    self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
                
                # Share a post if the message starts with 'Share' and author_id matches admin_id
                admin_id = '6949019840942160627'  # Replace with your actual admin ID
                
                if message.startswith('Share'):
                    if self.share:
                        reply = 'Đang Có Đơn Chưa Hoàn Thành. Vui Lòng Đợi Trong Vài Phút🤧🤧'
                        self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
                        return
                    else:
                        try:
                            id_post = message.split()[1]
                            lan = int(message.split()[2])
                            if lan > 100:
                                reply = 'Max 100'
                                self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
                                return
                            
                            x = requests.get(f'https://www.facebook.com/{id_post}').url
                            if 'videos' in x or 'reels' in x:
                                reply = 'Không thể buff share ảo cho videos. Nếu muốn buff share ảo cho videos thì gỡ videos đi buff xong rồi edit lại!'
                                self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
                                return
                            
                            if 'facebook' in x:
                                self.share = True
                                reply = f'Đơn tiếp theo cho ID {id_post}'
                                self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
                                
                                def f():
                                    try:
                                        result = run(id_post, lan)
                                        if result:
                                            reply = f'Tăng thành công {lan} shares cho ID {id_post}'
                                        else:
                                            reply = f'Tăng thất bại shares cho ID {id_post}'
                                    except Exception as e:
                                        reply = 'Xảy ra lỗi trong quá trình xử lý.'
                                        print(e)
                                    finally:
                                        self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
                                        self.share = False
                                
                                m = threading.Thread(target=f)
                                m.start()
                        
                        except Exception as e:
                            print(e)
                            reply = 'Buff Share Ảo Free Cho Ae\nCách Dùng : Share id_post số_lần\nMax: 100\nLưu Ý: Không dùng cho videos, muốn dùng cho videos cần gỡ videos rồi buff xong edit lại!'
                            self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
    
                  
                # Check FB profile if message starts with 'Fb'
                if message.startswith('Fb'):
                    try:
                        uid = message.split()[1]
                        # Assuming checkid function returns a dictionary with profile details
                        # Replace with actual implementation of checkid
                        check = checkid(uid)
                        reply = f'✅️CHECK SUCCESS✅️\n Uid: {check["idfb"]}\n Ngày Tạo: {check["created_time"]}\n Link Fb: {check["link"]}\n Tên Fb: {check["name"]}\n Quê Quán: {check["hometown"]}\n User: {check["username"]}\n Quốc Gia: {check["locale"]}\n Nơi Ở: {check["location"]}\n Web: {check["website"]}\n Giới Tính: {check["gender"]}\n Mối Quan Hệ: {check["relationship_status"]}\n Lượt Theo Dõi: {check["subscribers"]}\n Họ: {check["first_name"]}\n Ngày Sinh: {check["birthday"]}'
                        self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
                    
                    except Exception as e:
                        print(e)
                        reply = 'CÁCH SỬ DỤNG: Fb IDFB[Người Cần Check]'
                        self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)
        
        except Exception as e:
            print(e)
            reply = 'Bot đã xảy ra sự cố không xác định!'
            self.replyMessage(Message(text=reply), message_object, thread_id=thread_id, thread_type=thread_type)

# Initialize and start listening
client = TeeTan('</>', '</>', "a364337f-ace0-4285-8c97-a087533c4339-b78b4e2d6c0a362c418b145fe44ed73f", {"_ga":"GA1.2.854110349.1722652265","_gid":"GA1.2.1164327188.1722652265","_ga_VM4ZJE1265":"GS1.2.1722652265.1.0.1722652265.0.0.0","_ga_RYD7END4JE":"GS1.2.1722652267.1.1.1722652268.59.0.0","_zlang":"vn","zpsid":"Bjyp.362016986.0.fwOPea697CERUO_MJOaSmpJwRl1tkopoTx0azMl-a-PoPqHUG2oARYU97CC","zpw_sek":"gW9T.362016986.a0.B40yVIlaThBn5EMd2kHsib364za9tbJ7GRqZncNH8jSPhnkA6A0r-6YU6efSsKkGLiu1FGxNcEgsvT0aXe9siW","__zi":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8yuc-sYcaLGY7AJugRKGbA8SfFZfpCv.1","__zi-legacy":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8yuc-sYcaLGY7AJugRKGbA8SfFZfpCv.1","ozi":"2000.QOBlzDCV2uGerkFzm09LrMNTvFd62LVGBj_b_eWELT0kt-J_Cpa.1","app.event.zalo.me":"7370408023715644353"})
print('Bot ID:', client.uid)
client.listen()
