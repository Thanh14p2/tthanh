from fbchat import Client, log, Message
from fbchat.models import *
import __sendMessage 
from __facebookToolsV2 import dataGetHome
import random
import re
from reggrn import grn
from __uploadAttachments import _uploadAttachment
from apitik import gettik
import requests
import json
import sys
from rslistviewstr import remove_first_lines
import threading
from apicap import downcap
from viewstr import fb
from apicntfb import checkid
try:
    with open('config.json') as f:
        configuration = json.load(f)
except (FileNotFoundError, json.decoder.JSONDecodeError):
    print("Lỗi File config.json")
    sys.exit()

class AutoBot(Client):
    def __init__(self, email, password, session_cookies=None):
        super().__init__(email, password, session_cookies=session_cookies)
        self.tien= {}
    __sendMessage = __import__("__sendMessage")
    dataFB=dataGetHome("datr= uvrCZQTrqVmQK6Hkyiiro3R9; sb= uvrCZZsHofZjTMZUfDP5AwXm; fr= 0l8lCWPklciT7N76X.AWU5Xzr4RIw4CqVsq6k_3WfL7rI.Blwvq6.9L.AAA.0.0.Blwvq7.AWXRDupph8c; c_user= 100093063091825; xs= 15%3AG-PmffF1Ow2d0w%3A2%3A1707276987%3A-1%3A6274; m_page_voice= 100093063091825")
    def upload(self,filevd):
      upload=_uploadAttachment(filevd,self.dataFB)
      attachmentID=upload['attachmentID']
      return attachmentID
    def sendmessage(self,mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID):
      
      sendMessageCalled = self.__sendMessage.api()
      
      contentSend = reply
      threadID = thread_id
      typeAttachment = typeAttachment# Values: gif, image, video, file, audio
      attachmentID = attachmentID # This value is obtained from __uploadAttachments.py
      if thread_type == ThreadType.USER:
        typeChat='user'
      elif thread_type == ThreadType.GROUP:
        typeChat='Thread'
      # "user" = user / Other value = Thread
      replyMessage = None # None = reply / Other value = only send
      messageID = mid# messageID value e.g: mid.$gABESRz00DD6SixxBvWMWdb3w_KEg
      resultSendMessage = sendMessageCalled.send(self.dataFB, contentSend, threadID, typeAttachment, attachmentID, typeChat, replyMessage, messageID)
      print(resultSendMessage)
        

    def sendimg(self, author_id, thread_id, thread_type, image_url,reply):
        if author_id != self.uid:
            self.sendRemoteImage(image_url, message=Message(text=reply), thread_id=thread_id, thread_type=thread_type)
    def onMessage(self, mid=None, author_id=None, message_object=None, thread_id=None, thread_type=None,mentions=None ,**kwargs):
        global viewstr_progress
        msg = message_object.text
        rainbow_light_text_print("[ [ MESSAGE ] ] " + msg + " From " + author_id)
        if author_id != self.uid:
            Admin='100068672101423'
            if msg.startswith('Rsviewstr'):
              if author_id != Admin:
                reply='Chỉ Có Admin Mới Có Thể Dùng Lệnh Này'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              else:
                rs=remove_first_lines('idngoc.txt')
                if rs != False:
                  reply='Reset Thành Công 200 View Story.Người Dùng Có Thể Buff Thêm 200🥰'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Reggrn'):
              try:
                reg=grn()
                if reg['status'] != True:
                  reply='Reg Failed'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                user=reg['user']
                password=reg['password']
                uid=reg['uid']
                mail=reg['mail']
                passmail=reg['mailpass']
                reply=f'REG SUCCESS\nUser: {user}\nPassword: {password}\nUid: {uid}\nMail: {mail}\nPassmail: {passmail}'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                
              except Exception as e:
                print(e)
                reply='Cách Sử Dụng: Reggrn SốLượng'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Uid'):
              reply=author_id
              self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            Admin='100068672101423'
            if author_id not in self.tien or Admin not in self.tien:
              self.tien[author_id] = 100000
              self.tien[Admin] = 9999999999999999999
            if msg.startswith('Bank'):
              def bank():
                try:
                  idnhan=msg.split(' ')[1]
                  tiench=int(msg.split(' ')[2])
                  print(self.tien)
                  if author_id not in self.tien or idnhan not in self.tien:
                    reply='Người Chơi Không Tồn Tại'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  if tiench > self.tien[author_id]:
                    reply='Tiền Có Dell Đâu Mà Đòi Bank😎'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  else:
                    self.tien[author_id] -= tiench
                    self.tien[idnhan] += tiench
                    reply=f'Bank Thành Công {tiench} VNĐ Cho {idnhan}'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                except Exception as e:
                  print(e)
                  reply='Cách Sử Dụng: Bank IDFB(Nguoi Nhận) Tien(So Tiền Cần Bank)'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              bank()
                
            if msg.startswith('Money'):
              reply=f'Số Tiền Hiện Tại Của Bạn Là: {self.tien[author_id]} VNĐ'
              self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith('Txcl'):
              def game():
                try:
                  opt=msg.split(' ')[1]
                  money=int(msg.split(' ')[2])
                  option=['T','X','C','L']
                  if opt not in option:
                    reply='Sai Lựa Chọn\nTài:T\nXỉu:X\nChẵn:C\nLẻ:L'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  if money == 0 or money > self.tien[author_id] or money < 10000:
                    reply="Tiền Thì Dell Có Mà Đòi Chơi À Mày😎"
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    return
                  def txcl(result):
                    if result > 10:
                      return "Tài"
                    if result <= 10:
                      return "Xỉu"
                    if result % 2 == 0:
                      return "Chẵn"
                    else:
                      return "Lẻ"

                  def roll_dice():
                    return random.randint(1, 6)
                  dice_results = [roll_dice() for _ in range(3)]
                  total_dice = sum(dice_results)
                  is_even = total_dice % 2 == 0 
                  ketqua=txcl(total_dice)
                  if (opt == 'T' and total_dice > 10) or \
   (opt == 'X' and total_dice <= 10) or \
   (opt == 'C' and is_even) or \
   (opt == 'L' and not is_even):

                    self.tien[author_id] += int(money * 1.5)
                    reply=f'Thắng\nKết Quả:{ketqua}\nKết Quả 3 Lần Xúc Xắc:{dice_results}\nTổng:{total_dice}\nSố Tiền Hiện Tại Của Bạn Là: {self.tien[author_id]}'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  else:
                    self.tien[author_id] -= money
                    reply=f'Thua\nKết Quả:{ketqua}\nKết Quả 3 Lần Xúc Xắc:{dice_results}\nTổng:{total_dice}\nSố Tiền Hiện Tại Của Bạn Là: {self.tien[author_id]}'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                except:
                  reply='Cách Chơi: Txcl T/X/C/L Tiền'
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              game()
            if 'https://vt.tiktok.com/' in msg:
              try:
                x=re.compile(r'https://vt.tiktok.com/\w+/')
                matches = re.findall(x,msg)
                url=matches[0]
                title,duration,tym,comment_count,share_count,download_count,nickname,unique_id=gettik(url)
                reply=f'❤️GET SUCCESS❤️\n\nTitle: {title}\nThời Lượng:{duration}\nLượt Thích:{tym}\nLượt Bình Luận: {comment_count}\nLượt Share: {share_count}\nLượt Tải Xuống: {download_count}\nTác Giả: {nickname}({unique_id})'
                filevd='tiktok.mp4'
                typeAttachment='video'
                def upl(filevd):
                  attachmentID=self.upload(filevd)
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID)
                u=threading.Thread(target=upl,args=(filevd,))
                u.start()
              except:
                reply='REQUEST FAILED'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if 'https://www.capcut.com/t/' in msg:
              try:
                x=re.compile(r'https://www.capcut.com/t/\w+/')
                matches = re.findall(x,msg)
                url=matches[0]
                title,description,usage=downcap(url)
                reply=f'✅️          CAPCUT SUCCESS          ✅\n\nLINK:{url}\nTITLE: {title}\nDESCRIPTION: {description}\nLƯỢT NGƯỜI DÙNG: {usage}'
                filevd='capcut.mp4'
                typeAttachment='video'
                def upl(filevd):
                  attachmentID=self.upload(filevd)
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID)
                u=threading.Thread(target=upl,args=(filevd,))
                u.start()
              except:
                reply='REQUEST FAILED'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                
            if msg.startswith('In4'):
              try:
                uid=msg.split(' ')[1]
                check=checkid(uid)
                hometown=check['hometown']
                username=check['username']
                locale=check['locale']
                location=check['location']
                website=check['website']
                gender=check['gender']
                relationship_status=check['relationship_status']
                subscribers=check['subscribers']
                first_name=check['first_name']
                birthday=check['birthday']
                idfb=check['idfb']
                created_time=check['created_time']
                link=check['link']
                name=check['name']
                avt=check['avarta']
                reply=f'CHECK SUCCESS\n\nUID:{idfb}\nNGÀY_TẠO:{created_time}\nLINK:{link}\nNAME:{name}\nHOMETOWN:{hometown}\nUSERNAME:{username}\nLOCALE:{locale}\nLOCATION:{location}\nWEBSITE:{website}\nGIỚI TÍNH:{gender}\nMỐI QUAN HỆ:{relationship_status}\nFOLLOW:{subscribers}\nFIRST_NAME:{first_name}\nBIRTHDAY:{birthday}'
                image_url=avt
                self.sendimg(author_id, thread_id, thread_type, image_url,reply)
              except Exception as e:
                print(e)
                reply=('CÁCH SỬ DỤNG: In4 IDFB[Người Cần Check]')
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                
            if 'Vdgai' in msg:
              reply='❤         𝑽𝑰𝑫𝑬𝑶 𝑮𝑨𝑰         ❤\nAD: fb.com/thethanh1402'
              file=['girl.mp4','girl1.mp4','girl2.mp4','girl3.mp4']
              filevd=random.choice(file)
              typeAttachment='video'
              def upl(filevd):
                attachmentID=self.upload(filevd)
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment,attachmentID)
              u=threading.Thread(target=upl,args=(filevd,))
              u.start()
            bot=['Bot','bot','BOT']
            if any(msg.startswith(a) for a in bot):
              nhan=['𝗬𝗲̂𝘂 𝗘𝗺🥰','𝐺𝑜̣𝑖 𝐺𝑖̀ 𝑉𝑎̣̂𝑦 𝐸𝑚 𝐼𝑢❤️','𝐺𝑜̣𝑖 𝐶𝑜𝑛 𝐶𝑎𝑘😎']
              reply=random.choice(nhan)
              self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if 'girl' in msg:
                
                image_url = requests.get('https://tthanhvippro.000webhostapp.com/getanh.php').text
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
            if msg.startswith(f"Viewstr"):
              if viewstr_progress:
                reply='⌛Hiện Tại Đang Có 1 Đơn Chưa Hoàn Thành.Vui Lòng Chờ Trong Vài Phút!'
                self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
              else:
                viewstr_progress=True
                try:
                  link = msg.split(' ')[1]
                  a = int(msg.split(' ')[2])
                  if not 'https://www.facebook.com/stories/' in link:
                    reply='Sai Link Story FACEBOOK Rồi Bạn Ơi!'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    viewstr_progress=False
                  if a > 200:
                    reply=f' Max 200 Bạn Ơi🤧'
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  else:
                    reply = f' Đơn Tiếp Theo\n\n{a} View  Story Cho Link:{link} '
                    self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    def r():
                      try:
                        idstr = link.split('/')[5].split('/?')[0]
                        fb(idstr, link,a)
                      except Exception as e:
                        return str(e)
                      finally:
                        global viewstr_progress
                        viewstr_progress=False
                        reply = f"🗒ORDER SUCCESSFUL\n\nĐã Buff {a} View Story Cho Link:{link}"
                        self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                    success_viewstr=threading.Thread(target=r)
                    success_viewstr.start()
                except Exception as e:
                  print(f"Error in onMessage: {e}")
                  reply='Cách Sử Dụng: Viewstr Linkstr Số Lượng\n\nMax:200 View\nLưu Ý: Chỉ Buff 1 Lần Spam Buff Sẽ Không Lên. Admin Sẽ Reset Tài Nguyên Thường Xuyên Khi Reset Xong Ad Sẽ Báo Và Có Thể Lên Tiếp Được🥰 '
                  self.sendmessage(mid,author_id, thread_id,reply,thread_type,typeAttachment=None,attachmentID=None)
                  viewstr_progress= False

viewstr_progress=False

# Thêm thông tin về cookies và khởi tạo bot


def rainbow_light_text_print(text, end='\n'):
    colors = ["\033[91m", "\033[93m", "\033[92m", "\033[96m", "\033[94m", "\033[95m"]
    num_steps = len(colors)
    for i, char in enumerate(text):
        color_index = i % num_steps
        print(f"{colors[color_index]}{char}", end="")
    print("\033[0m", end=end)

try:
  session_cookies = {
    'sb': 'uvrCZZsHofZjTMZUfDP5AwXm',
    'datr': 'uvrCZQTrqVmQK6Hkyiiro3R9',
    'c_user': '100093063091825',
    'fr': '0l8lCWPklciT7N76X.AWU5Xzr4RIw4CqVsq6k_3WfL7rI.Blwvq6.9L.AAA.0.0.Blwvq7.AWXRDupph8c',
    'xs': '15%3AG-PmffF1Ow2d0w%3A2%3A1707276987%3A-1%3A6274',
}
  bot = AutoBot('', '', session_cookies=session_cookies)
  rainbow_light_text_print("[ [ CONNECTING ] ] {}".format(str(bot.isLoggedIn()).upper()))
except:
  sys.exit("\033[91m[ [ ERROR ] ] FAILED TO CONNECT TO SERVER, TRY TO RERUN TO PROGRAM. \033[0m")
try:
  bot.listen()
except:
  bot.listen()
#datr= ; sb= ; fr= ; c_user= 100093063091825; xs= ; m_page_voice= 100093063091825