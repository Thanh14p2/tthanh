import requests
import urllib.parse
def downcap(url):
  headers = {
    'authority': 'ssscap.net',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
    'cache-control': 'max-age=0',
    # 'cookie': 'sign=799144ab41d9b13dbee366baf6a65152; device-time=1704555215302',
    'referer': 'https://vn.search.yahoo.com/',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
}
  response = requests.get('https://ssscap.net/',headers=headers).text
  sign=response.split('{"sign":"')[1].split('"')[0]
  time=response.split('"time":"')[1].split('"}')[0]
  cookies = {
    'sign': sign,
    'device-time': time,
}

  response = requests.get(
    f'https://ssscap.net/api/download/get-url?url={url}',
    cookies=cookies,
    headers=headers,
).text 
  idcap=response.split('/')[4]
  apidown=requests.get('https://ssscap.net/api/download/'+idcap,cookies=cookies,headers=headers).json()
  originalVideoUrl=apidown['originalVideoUrl']
  down=requests.get(f'https://ssscap.net{originalVideoUrl}',cookies=cookies,headers=headers).content
  open('capcut.mp4','wb').write(down)
  title=apidown['title']
  description=apidown['description']
  usage=apidown['usage']
  return title,description,usage
